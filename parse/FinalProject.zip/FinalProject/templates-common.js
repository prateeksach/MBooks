angular.module('templates-common', []);

